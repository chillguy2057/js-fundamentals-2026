// TEEMA 13: Moodulid — abifail (mathHelpers.mjs)

// --- Nimeline eksport (named export) ---
// Võib olla mitu named export'i ühes failis
export function add(a, b) {
  return a + b;
}

export function multiply(a, b) {
  return a * b;
}

export const PI = 3.14159;

// --- Vaikimisi eksport (default export) ---
// Failis võib olla AINULT ÜKS default export
export default function subtract(a, b) {
  return a - b;
}
