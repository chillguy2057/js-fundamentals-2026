// TEEMA 15: Andmete pärimine, JSON ja veakäsitlus

// --- Andmete pärimine fetch()-iga ---
async function fetchTodo() {
  const response = await fetch("https://jsonplaceholder.typicode.com/todos/1");
  console.log("Response objekt saadud, staatus:", response.status);

  // --- response.ok kontrollimine ---
  // response.ok on true, kui HTTP staatus on vahemikus 200-299
  if (!response.ok) {
    throw new Error(`HTTP viga! Staatus: ${response.status}`);
  }

  // --- JSON lugemine await response.json() abil ---
  const data = await response.json();
  console.log("Saadud JSON andmed:", data);
  return data;
}

// --- Erinevus JSON-i ja JavaScripti objekti vahel ---
// JSON on tekst (string) andmete edastamiseks - "{"name":"Artjom"}"
// JS objekt on mälus olev struktuur, millega saab otse töötada
const jsonString = '{"name":"Artjom","age":21}'; // see on STRING
console.log("JSON string tüüp:", typeof jsonString); // "string"

const jsObject = JSON.parse(jsonString); // teisendab JSON-i JS objektiks
console.log("JS objekti tüüp:", typeof jsObject); // "object"
console.log("Ligipääs omadusele:", jsObject.name); // "Artjom" - see töötab ainult objektil, mitte stringil

const backToJson = JSON.stringify(jsObject); // teisendab JS objekti tagasi JSON stringiks
console.log("Tagasi JSON stringiks:", backToJson, typeof backToJson);

// --- Vigade käsitlemine try ja catch abil ---
async function safeApiCall() {
  try {
    const data = await fetchTodo();
    console.log("Õnnestus:", data.title);
  } catch (error) {
    console.log("Viga püüti kinni:", error.message);
  }
}
safeApiCall();

// --- Miks HTTP viga (nt 404) vajab eraldi kontrolli ---
// fetch() VISKAB VEA ainult siis, kui päring täielikult ebaõnnestub
// (nt puudub internetiühendus). 404, 500 jms staatused EI viska automaatselt viga!
async function demonstrateHttpErrorTrap() {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/todos/999999999");
    console.log("fetch ei visanud viga isegi kui staatus on:", response.status);
    // Kui me ei kontrolliks response.ok, jätkaks kood justkui kõik oleks korras
    if (!response.ok) {
      throw new Error(`Server tagastas vea: ${response.status}`);
    }
    const data = await response.json();
    console.log("Andmed:", data);
  } catch (error) {
    console.log("Käsitletud HTTP viga:", error.message);
  }
}
demonstrateHttpErrorTrap();

// --- Levinud algaja viga ---
// Viga: eeldatakse, et try/catch püüab kinni ka 404/500 vead ilma response.ok kontrollita
async function mistakeExample() {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/todos/999999999");
    const data = await response.json(); // see EI viska viga, isegi kui staatus on 404
    console.log("Viga - jätkati justkui kõik on korras:", data); // {} tühi objekt, aga koodi arvates kõik OK
  } catch (error) {
    console.log("See catch tõenäoliselt ei käivitu 404 puhul:", error.message);
  }
}
mistakeExample();
// Parandus: kontrolli ALATI response.ok, enne kui usaldad andmeid, vt demonstrateHttpErrorTrap()

// --- Predict the output ---
// Mida prindib see kood, kui URL on valesti kirjutatud domeen (ei eksisteeri)?
async function predictOutput() {
  try {
    await fetch("https://see-domeen-ei-eksisteeri-kunagi-12345.com/data");
    console.log("Kutse õnnestus");
  } catch (error) {
    console.log("Kutse ebaõnnestus võrgu tasemel - see JOOKSEB, sest fetch viskab viga puuduva ühenduse korral");
  }
}
predictOutput();
